package skhu.model;

public class Notice {

}
