package skhu.model;

public class Sms {

}
