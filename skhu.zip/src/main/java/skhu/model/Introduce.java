package skhu.model;

public class Introduce {

}
