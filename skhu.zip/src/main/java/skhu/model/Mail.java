package skhu.model;

public class Mail {

}
