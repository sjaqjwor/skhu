package skhu.model;

public class Comment {

}
