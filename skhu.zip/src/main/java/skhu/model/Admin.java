package skhu.model;

public class Admin {
	private String a_id;
	private String a_loginId;
	private String a_password;
	
	public String getA_id() {
		return a_id;
	}
	public void setA_id(String a_id) {
		this.a_id = a_id;
	}
	public String getA_loginId() {
		return a_loginId;
	}
	public void setA_loginId(String a_loginId) {
		this.a_loginId = a_loginId;
	}
	public String getA_password() {
		return a_password;
	}
	public void setA_password(String a_password) {
		this.a_password = a_password;
	}
}

