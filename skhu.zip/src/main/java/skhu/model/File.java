package skhu.model;

public class File {

}
