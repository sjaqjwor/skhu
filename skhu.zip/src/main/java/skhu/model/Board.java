package skhu.model;

public class Board {

}
